<?php
namespace MercadoPago;

class Version
{
    public static
        $_VERSION = '2.6.2';
}
