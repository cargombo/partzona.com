<?php

namespace Iyzipay\Model;

class Status {
    const SUCCESS = "success";
    const FAILURE = "failure";
    const ACTIVE = "ACTIVE";
    const PASSIVE = "PASSIVE";
}