<?php
namespace Aws\Arn\Exception;

/**
 * Represents a failed attempt to construct an Arn
 */
class InvalidArnException extends \RuntimeException {}
