# Facade

LaravelPayku::knowFilledKeys();
LaravelPayku::hasValidConfig();
LaravelPayku::createOrder();
