<?php

return [
    'title' => 'Missing route',
    'it_works' => 'It works!',
    'finished_1' => 'Your order was finished! but if you want to show a nice view, you need to create a route with name',
    'finished_2' => 'to showing final result to your user',
];
