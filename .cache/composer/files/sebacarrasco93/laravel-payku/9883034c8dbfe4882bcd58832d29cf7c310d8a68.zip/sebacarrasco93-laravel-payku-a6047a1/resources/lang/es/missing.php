<?php

return [
    'title' => 'Falta una ruta',
    'it_works' => 'Funciona!',
    'finished_1' => 'Tu orden fue creada! pero si quieres agregar una hermosa vista, necesitas crear una ruta con el nombre',
    'finished_2' => 'para mostrar el resultado final a tu usuario',
];
