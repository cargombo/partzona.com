<?php

namespace SebaCarrasco93\LaravelPayku\Payments;

class Webpay extends Payment
{
    public static $code = 1;
}
