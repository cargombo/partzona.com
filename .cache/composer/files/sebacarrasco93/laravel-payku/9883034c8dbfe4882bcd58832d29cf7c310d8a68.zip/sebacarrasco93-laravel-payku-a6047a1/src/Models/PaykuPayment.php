<?php

namespace SebaCarrasco93\LaravelPayku\Models;

class PaykuPayment extends Model
{
}
