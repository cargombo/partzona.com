# combination-generate
Generate combinations of items in multiple arrays
