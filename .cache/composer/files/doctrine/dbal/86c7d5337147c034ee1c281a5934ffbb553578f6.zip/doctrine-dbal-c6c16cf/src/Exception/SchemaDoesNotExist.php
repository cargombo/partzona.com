<?php

namespace Doctrine\DBAL\Exception;

class SchemaDoesNotExist extends DatabaseObjectNotFoundException
{
}
