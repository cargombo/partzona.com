# Introduction

This is needed for merchants that do not want to use Flutterwave Payment Modal, and want to implement the APIs directly
