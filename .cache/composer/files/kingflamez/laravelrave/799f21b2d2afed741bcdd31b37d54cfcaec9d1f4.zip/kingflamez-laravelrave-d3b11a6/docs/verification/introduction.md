# Payment Verification

When a user is done with payment, Flutterwave would redirect to your redirect url if present or hit your webhook url:

Please make sure one of this is available as it is important to verify all transactions before giving value to it

## [Webhook Notification](/verification/webhook.html) 

## [Callback Notification](/verification/callback.html) 
