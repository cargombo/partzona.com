# laravel-overridable-model
Provide a uniform method of allowing models to be overridden in Laravel.

## Installation
```sh
composer require genealabs/laravel-overridable-model
```

## Usage
### Contract

### Trait
