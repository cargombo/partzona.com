<! DOCTYPE html>
<html>
    <head>
    </head>
    <body>
        <div>
            @signInWithApple("black", false, "sign-in", 6)
        </div>
    </body>
</html>
