<?php

namespace GeneaLabs\LaravelSignInWithApple\Tests;

use Orchestra\Testbench\Dusk\TestCase;

abstract class BrowserTestCase extends TestCase
{
    use CreatesApplication;
}
