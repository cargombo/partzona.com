<?php

namespace GeneaLabs\LaravelSignInWithApple\Tests;

use Orchestra\Testbench\TestCase;

abstract class UnitTestCase extends TestCase
{
    use CreatesApplication;
}
